"""
Editorial permission classes.
Used by both DRF API views and the web dashboard views.
"""

from rest_framework.permissions import BasePermission, SAFE_METHODS


class IsAE(BasePermission):
    """Only Assistant Editors."""
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == 'ae'


class IsSE(BasePermission):
    """Only Senior Editors."""
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == 'se'


class IsCE(BasePermission):
    """Only Chief Editors."""
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == 'ce'


class IsAEOrAbove(BasePermission):
    """AE, SE, or CE."""
    EDITOR_ROLES = {'ae', 'se', 'ce'}

    def has_permission(self, request, view):
        return (
            request.user.is_authenticated
            and request.user.role in self.EDITOR_ROLES
        )


class IsSEOrAbove(BasePermission):
    """SE or CE only."""
    EDITOR_ROLES = {'se', 'ce'}

    def has_permission(self, request, view):
        return (
            request.user.is_authenticated
            and request.user.role in self.EDITOR_ROLES
        )


class IsAssignedAEForReview(BasePermission):
    """
    The requesting AE must be the one assigned to this specific review.
    SEs and CEs always pass (they have broader oversight).
    """
    def has_object_permission(self, request, view, obj):
        user = request.user
        if not user.is_authenticated:
            return False
        if user.role in ('se', 'ce'):
            return True
        if user.role == 'ae':
            return obj.assigned_ae == user
        return False


class IsSEForReview(BasePermission):
    """
    The requesting SE must be assigned to this review (or a CE).
    """
    def has_object_permission(self, request, view, obj):
        user = request.user
        if not user.is_authenticated:
            return False
        if user.role == 'ce':
            return True
        if user.role == 'se':
            return obj.assigned_se == user
        return False


# ─── Django view helpers (not DRF) ───────────────────────────────────────────

def require_role(*roles):
    """
    Decorator for Django web views. Redirects to login if user does not
    have one of the specified roles.

    Usage:
        @require_role('ae', 'se', 'ce')
        def my_view(request):
            ...
    """
    from functools import wraps
    from django.shortcuts import redirect

    def decorator(view_func):
        @wraps(view_func)
        def _wrapped(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect('/login/?next=' + request.path)
            if hasattr(request.user, 'role') and request.user.role not in roles:
                return redirect('/login/?next=' + request.path)
            return view_func(request, *args, **kwargs)
        return _wrapped
    return decorator


def editor_context(user):
    """
    Returns a dict of useful editorial context variables to inject into
    any editor dashboard template context.
    """
    from apps.editorial.models import ChapterReview, ContentFlag, EditorAssignment

    ctx = {
        'editor_role': user.role,
        'editor_username': user.username,
        'editor_email': user.email,
    }

    if user.role == 'ae':
        ctx['queue_count'] = ChapterReview.objects.filter(
            assigned_ae=user,
            status__in=['pending', 'ae_reviewing'],
        ).count()
        ctx['urgent_count'] = ChapterReview.objects.filter(
            assigned_ae=user,
            status__in=['pending', 'ae_reviewing'],
            priority='urgent',
        ).count()
        ctx['flagged_count'] = ContentFlag.objects.filter(
            flagged_by=user,
            resolved=False,
        ).count()
        ctx['reviewed_today'] = ChapterReview.objects.filter(
            assigned_ae=user,
            status__in=['ae_approved', 'ae_revision', 'ae_escalated'],
            updated_at__date=__import__('django.utils.timezone', fromlist=['now']).now().date(),
        ).count()
        # How many authors this AE is responsible for
        ctx['author_count'] = user.assigned_authors.count()
        # Supervisor SE
        try:
            ctx['supervisor_se'] = user.editorial_assignment.supervisor
        except Exception:
            ctx['supervisor_se'] = None

    elif user.role == 'se':
        ctx['escalation_count'] = ChapterReview.objects.filter(
            assigned_se=user,
            status='ae_escalated',
        ).count()
        ctx['ae_team'] = list(
            user.subordinates.filter(role='ae')
            .values('id', 'username', 'email')
        )
        ctx['ae_team_count'] = len(ctx['ae_team'])
        try:
            ctx['supervisor_ce'] = user.editorial_assignment.supervisor
        except Exception:
            ctx['supervisor_ce'] = None

    elif user.role == 'ce':
        ctx['ce_escalation_count'] = ChapterReview.objects.filter(
            status='se_escalated',
        ).count()
        ctx['se_team'] = list(
            user.subordinates.filter(role='se')
            .values('id', 'username', 'email')
        )
        from apps.editorial.models import EditorialPolicy
        ctx['pending_policies'] = EditorialPolicy.objects.filter(
            status='under_review',
        ).count()

    return ctx
