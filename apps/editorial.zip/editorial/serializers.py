from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import (
    EditorAssignment, AuthorEditorLink, ChapterReview,
    EditorialNote, ContentFlag, PolicyDecision, EditorialPolicy,
)

User = get_user_model()


class EditorMinimalSerializer(serializers.ModelSerializer):
    class Meta:
        model  = User
        fields = ['id', 'username', 'email', 'role']


class EditorAssignmentSerializer(serializers.ModelSerializer):
    editor_detail     = EditorMinimalSerializer(source='editor',     read_only=True)
    supervisor_detail = EditorMinimalSerializer(source='supervisor', read_only=True)

    class Meta:
        model  = EditorAssignment
        fields = ['id', 'editor', 'supervisor', 'editor_detail', 'supervisor_detail',
                  'assigned_at', 'notes']

    def validate_editor(self, value):
        if value.role not in ('ae', 'se'):
            raise serializers.ValidationError('Editor must have role ae or se.')
        return value

    def validate_supervisor(self, value):
        if value and value.role not in ('se', 'ce'):
            raise serializers.ValidationError('Supervisor must be an SE or CE.')
        return value


class AuthorEditorLinkSerializer(serializers.ModelSerializer):
    author_detail = EditorMinimalSerializer(source='author',      read_only=True)
    ae_detail     = EditorMinimalSerializer(source='assigned_ae', read_only=True)
    supervising_se = serializers.SerializerMethodField()
    ce             = serializers.SerializerMethodField()

    class Meta:
        model  = AuthorEditorLink
        fields = ['id', 'author', 'assigned_ae', 'author_detail', 'ae_detail',
                  'supervising_se', 'ce', 'assigned_at', 'notes']

    def get_supervising_se(self, obj):
        se = obj.get_supervising_se()
        return EditorMinimalSerializer(se).data if se else None

    def get_ce(self, obj):
        ce = obj.get_ce()
        return EditorMinimalSerializer(ce).data if ce else None


class EditorialNoteSerializer(serializers.ModelSerializer):
    author_username = serializers.CharField(source='author.username', read_only=True)

    class Meta:
        model  = EditorialNote
        fields = ['id', 'review', 'author', 'author_username', 'note_type',
                  'content', 'paragraph', 'is_resolved', 'created_at']
        read_only_fields = ['author', 'created_at']

    def create(self, validated_data):
        validated_data['author'] = self.context['request'].user
        return super().create(validated_data)


class ContentFlagSerializer(serializers.ModelSerializer):
    flagged_by_username  = serializers.CharField(source='flagged_by.username',  read_only=True)
    resolved_by_username = serializers.CharField(source='resolved_by.username', read_only=True)

    class Meta:
        model  = ContentFlag
        fields = ['id', 'review', 'flagged_by', 'flagged_by_username', 'flag_type',
                  'description', 'created_at', 'resolved', 'resolved_by',
                  'resolved_by_username', 'resolution_note']
        read_only_fields = ['flagged_by', 'created_at']

    def create(self, validated_data):
        validated_data['flagged_by'] = self.context['request'].user
        return super().create(validated_data)


class ChapterReviewListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for lists/queues."""
    chapter_title  = serializers.CharField(source='chapter.title',        read_only=True)
    story_title    = serializers.CharField(source='chapter.story.title',  read_only=True)
    author_name    = serializers.CharField(source='author.username',      read_only=True)
    ae_name        = serializers.CharField(source='assigned_ae.username', read_only=True)
    se_name        = serializers.CharField(source='assigned_se.username', read_only=True)
    word_count     = serializers.IntegerField(source='chapter.word_count', read_only=True)
    flag_count     = serializers.IntegerField(source='flags.count',       read_only=True)
    note_count     = serializers.IntegerField(source='notes.count',       read_only=True)

    class Meta:
        model  = ChapterReview
        fields = [
            'id', 'chapter', 'chapter_title', 'story_title', 'author_name',
            'ae_name', 'se_name', 'status', 'priority',
            'submitted_at', 'updated_at', 'turnaround_hours',
            'flag_count', 'note_count', 'word_count',
        ]


class ChapterReviewDetailSerializer(serializers.ModelSerializer):
    """Full serializer for review detail view."""
    notes  = EditorialNoteSerializer(many=True, read_only=True)
    flags  = ContentFlagSerializer(many=True,   read_only=True)
    chapter_title   = serializers.CharField(source='chapter.title',        read_only=True)
    story_title     = serializers.CharField(source='chapter.story.title',  read_only=True)
    author_name     = serializers.CharField(source='author.username',      read_only=True)
    chapter_content = serializers.CharField(source='chapter.content',      read_only=True)
    word_count      = serializers.IntegerField(source='chapter.word_count', read_only=True)

    class Meta:
        model  = ChapterReview
        fields = [
            'id', 'chapter', 'chapter_title', 'story_title', 'author_name',
            'chapter_content', 'word_count',
            'assigned_ae', 'assigned_se', 'assigned_ce',
            'status', 'priority',
            'pacing_score', 'dialogue_score', 'consistency_score',
            'submitted_at', 'updated_at', 'resolved_at', 'turnaround_hours',
            'notes', 'flags',
        ]
        read_only_fields = ['submitted_at', 'updated_at', 'author']


class PolicyDecisionSerializer(serializers.ModelSerializer):
    decided_by_username = serializers.CharField(source='decided_by.username', read_only=True)
    review_chapter      = serializers.CharField(
        source='review.chapter.title', read_only=True,
    )

    class Meta:
        model  = PolicyDecision
        fields = ['id', 'review', 'review_chapter', 'decided_by', 'decided_by_username',
                  'ruling', 'reasoning', 'sets_precedent', 'notified_se', 'decided_at']
        read_only_fields = ['decided_by', 'decided_at']

    def create(self, validated_data):
        validated_data['decided_by'] = self.context['request'].user
        return super().create(validated_data)


class EditorialPolicySerializer(serializers.ModelSerializer):
    proposed_by_name = serializers.CharField(source='proposed_by.username', read_only=True)
    approved_by_name = serializers.CharField(source='approved_by.username', read_only=True)

    class Meta:
        model  = EditorialPolicy
        fields = ['id', 'title', 'version', 'content', 'status',
                  'proposed_by', 'proposed_by_name', 'approved_by', 'approved_by_name',
                  'created_at', 'published_at', 'notes']
        read_only_fields = ['proposed_by', 'approved_by', 'created_at']
