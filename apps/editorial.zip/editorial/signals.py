"""
Editorial Signals
=================
1. When a User with role=ae is saved for the first time → auto-generate editor_code
2. When a Chapter transitions to status='submitted' → create ChapterReview ticket
   and resolve the AE from the author's AuthorEditorLink
"""

from django.db.models.signals import post_save
from django.dispatch import receiver


# ─── 1. Auto-generate editor_code for new AE accounts ────────────────────────

@receiver(post_save, sender='users.User')
def generate_ae_editor_code(sender, instance, created, **kwargs):
    """
    As soon as an AE account is saved (created OR role changed to ae),
    ensure they have an editor_code.
    """
    if instance.role != 'ae':
        return
    if instance.editor_code:
        return
    # Call generate_editor_code() which saves itself
    instance.generate_editor_code()


# ─── 2. Auto-create ChapterReview on chapter submission ──────────────────────

@receiver(post_save, sender='chapters.Chapter')
def create_review_on_submission(sender, instance, created, **kwargs):
    """
    When a chapter's status becomes 'submitted', open a ChapterReview ticket.
    The AE is resolved from the author's AuthorEditorLink:
      - If the author has a link → assigned to their AE
      - If no link yet → auto_assign to lowest-load AE
      - If still none → review sits unassigned (CE/admin will pick it up)
    """
    if not instance.is_published:
        return

    from apps.editorial.models import ChapterReview, AuthorEditorLink

    # Avoid duplicate tickets
    if ChapterReview.objects.filter(chapter=instance).exists():
        return

    author = instance.story.author

    assigned_ae = None
    assigned_se = None
    assigned_ce = None

    # Try to get existing link
    try:
        link = AuthorEditorLink.objects.select_related(
            'assigned_ae__editorial_assignment__supervisor'
            '__editorial_assignment__supervisor'
        ).get(author=author)
    except AuthorEditorLink.DoesNotExist:
        # No link yet — auto-assign
        link, _ = AuthorEditorLink.auto_assign(author)

    if link and link.assigned_ae:
        assigned_ae = link.assigned_ae
        assigned_se = link.get_supervising_se()
        assigned_ce = link.get_ce()

    ChapterReview.objects.create(
        chapter     = instance,
        author      = author,
        assigned_ae = assigned_ae,
        assigned_se = assigned_se,
        assigned_ce = assigned_ce,
        priority    = ChapterReview.PRIORITY_NORMAL,
        status      = ChapterReview.STATUS_PENDING,
    )
