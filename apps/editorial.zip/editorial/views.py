"""
Editorial API Views
===================
AE endpoints:  /api/editorial/queue/          GET
               /api/editorial/reviews/<id>/   GET, PATCH
               /api/editorial/reviews/<id>/approve/
               /api/editorial/reviews/<id>/request-revision/
               /api/editorial/reviews/<id>/escalate-to-se/
               /api/editorial/notes/          POST
               /api/editorial/flags/          POST

SE endpoints:  /api/editorial/escalations/    GET (AE-escalated)
               /api/editorial/reviews/<id>/se-approve/
               /api/editorial/reviews/<id>/se-revision/
               /api/editorial/reviews/<id>/escalate-to-ce/
               /api/editorial/reviews/<id>/remove/
               /api/editorial/ae-team/        GET (SE's AE list)

CE endpoints:  /api/editorial/ce-escalations/ GET
               /api/editorial/reviews/<id>/ce-approve/
               /api/editorial/reviews/<id>/ce-revision/
               /api/editorial/reviews/<id>/ce-remove/
               /api/editorial/reviews/<id>/suspend-author/
               /api/editorial/policy-decisions/ GET, POST
               /api/editorial/policies/       GET, POST
               /api/editorial/policies/<id>/approve/
               /api/editorial/team/           GET  (full org view)

Shared:        /api/editorial/author-links/   GET, POST  (CE/admin only)
               /api/editorial/assignments/    GET, POST  (CE/admin only)
               /api/editorial/stats/          GET
"""

from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.contrib.auth import get_user_model
from django.db.models import Avg, Count, Q

from rest_framework import generics, status, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import (
    EditorAssignment, AuthorEditorLink, ChapterReview,
    EditorialNote, ContentFlag, PolicyDecision, EditorialPolicy,
)
from .serializers import (
    EditorAssignmentSerializer, AuthorEditorLinkSerializer,
    ChapterReviewListSerializer, ChapterReviewDetailSerializer,
    EditorialNoteSerializer, ContentFlagSerializer,
    PolicyDecisionSerializer, EditorialPolicySerializer,
)
from .permissions import IsAEOrAbove, IsSEOrAbove, IsCE, IsAE, IsSE

User = get_user_model()


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _transition(review, new_status, actor_field=None, actor=None):
    """Update review status and optionally set an actor field."""
    review.status = new_status
    update_fields = ['status', 'updated_at']
    if actor_field and actor:
        setattr(review, actor_field, actor)
        update_fields.append(actor_field)
    if new_status in (
        ChapterReview.STATUS_AE_APPROVED,
        ChapterReview.STATUS_SE_APPROVED,
        ChapterReview.STATUS_CE_APPROVED,
        ChapterReview.STATUS_REMOVED,
        ChapterReview.STATUS_AUTHOR_SUSPENDED,
    ):
        review.resolved_at = timezone.now()
        update_fields.append('resolved_at')
    review.save(update_fields=update_fields)


# ─── AE Views ─────────────────────────────────────────────────────────────────

class AEQueueView(generics.ListAPIView):
    """
    GET /api/editorial/queue/
    Returns the chapters currently in the requesting AE's review queue.
    """
    serializer_class   = ChapterReviewListSerializer
    permission_classes = [IsAE]

    def get_queryset(self):
        qs = ChapterReview.objects.filter(
            assigned_ae=self.request.user,
            status__in=[
                ChapterReview.STATUS_PENDING,
                ChapterReview.STATUS_AE_REVIEWING,
            ],
        ).select_related('chapter', 'chapter__story', 'author', 'assigned_ae')

        priority = self.request.query_params.get('priority')
        if priority:
            qs = qs.filter(priority=priority)
        return qs


class AEReviewDetailView(generics.RetrieveUpdateAPIView):
    """
    GET  /api/editorial/reviews/<id>/
    PATCH /api/editorial/reviews/<id>/  (update scores, notes inline)
    """
    serializer_class   = ChapterReviewDetailSerializer
    permission_classes = [IsAEOrAbove]

    def get_queryset(self):
        user = self.request.user
        if user.role == 'ae':
            return ChapterReview.objects.filter(assigned_ae=user)
        if user.role == 'se':
            return ChapterReview.objects.filter(assigned_se=user)
        # CE sees all
        return ChapterReview.objects.all()

    def get_object(self):
        obj = get_object_or_404(self.get_queryset(), pk=self.kwargs['pk'])
        # Mark as actively reviewing when opened
        if obj.status == ChapterReview.STATUS_PENDING:
            obj.status = ChapterReview.STATUS_AE_REVIEWING
            obj.save(update_fields=['status'])
        return obj


@api_view(['POST'])
@permission_classes([IsAE])
def ae_approve(request, pk):
    """POST /api/editorial/reviews/<id>/approve/"""
    review = get_object_or_404(ChapterReview, pk=pk, assigned_ae=request.user)
    _transition(review, ChapterReview.STATUS_AE_APPROVED)
    # Auto-publish chapter
    review.chapter.is_published = True
    review.chapter.save(update_fields=['is_published'])
    return Response({'status': 'approved', 'review_id': review.id})


@api_view(['POST'])
@permission_classes([IsAE])
def ae_request_revision(request, pk):
    """POST /api/editorial/reviews/<id>/request-revision/"""
    review = get_object_or_404(ChapterReview, pk=pk, assigned_ae=request.user)
    message = request.data.get('message', '')
    _transition(review, ChapterReview.STATUS_AE_REVISION)
    # Create a feedback note
    if message:
        EditorialNote.objects.create(
            review=review,
            author=request.user,
            note_type=EditorialNote.NOTE_TYPE_GENERAL,
            content=message,
        )
    return Response({'status': 'revision_requested', 'review_id': review.id})


@api_view(['POST'])
@permission_classes([IsAE])
def ae_escalate_to_se(request, pk):
    """POST /api/editorial/reviews/<id>/escalate-to-se/"""
    review = get_object_or_404(ChapterReview, pk=pk, assigned_ae=request.user)
    flag_type   = request.data.get('flag_type', ContentFlag.FLAG_OTHER)
    description = request.data.get('description', '')

    # Resolve the supervising SE via hierarchy
    se = None
    try:
        se = request.user.editorial_assignment.supervisor
        if se and se.role != 'se':
            se = None
    except EditorAssignment.DoesNotExist:
        pass

    review.assigned_se = se
    _transition(review, ChapterReview.STATUS_AE_ESCALATED, 'assigned_se', se)

    # Create flag record
    if description or flag_type:
        ContentFlag.objects.create(
            review=review,
            flagged_by=request.user,
            flag_type=flag_type,
            description=description,
        )

    return Response({
        'status': 'escalated_to_se',
        'review_id': review.id,
        'se_assigned': se.username if se else None,
    })


# ─── SE Views ─────────────────────────────────────────────────────────────────

class SEEscalationsView(generics.ListAPIView):
    """
    GET /api/editorial/escalations/
    Chapters escalated to this SE for decision.
    """
    serializer_class   = ChapterReviewListSerializer
    permission_classes = [IsSEOrAbove]

    def get_queryset(self):
        user = self.request.user
        if user.role == 'se':
            return ChapterReview.objects.filter(
                assigned_se=user,
                status=ChapterReview.STATUS_AE_ESCALATED,
            ).select_related('chapter', 'chapter__story', 'author', 'assigned_ae')
        # CE sees all SE-level escalations
        return ChapterReview.objects.filter(
            status=ChapterReview.STATUS_AE_ESCALATED,
        ).select_related('chapter', 'chapter__story', 'author', 'assigned_ae', 'assigned_se')


@api_view(['POST'])
@permission_classes([IsSEOrAbove])
def se_approve(request, pk):
    """POST /api/editorial/reviews/<id>/se-approve/"""
    review = get_object_or_404(ChapterReview, pk=pk)
    _transition(review, ChapterReview.STATUS_SE_APPROVED)
    review.chapter.is_published = True
    review.chapter.save(update_fields=['is_published'])
    return Response({'status': 'se_approved', 'review_id': review.id})


@api_view(['POST'])
@permission_classes([IsSEOrAbove])
def se_request_revision(request, pk):
    """POST /api/editorial/reviews/<id>/se-revision/"""
    review = get_object_or_404(ChapterReview, pk=pk)
    message = request.data.get('message', '')
    _transition(review, ChapterReview.STATUS_SE_REVISION)
    if message:
        EditorialNote.objects.create(
            review=review,
            author=request.user,
            note_type=EditorialNote.NOTE_TYPE_DECISION,
            content=message,
        )
    return Response({'status': 'se_revision_requested', 'review_id': review.id})


@api_view(['POST'])
@permission_classes([IsSEOrAbove])
def se_escalate_to_ce(request, pk):
    """POST /api/editorial/reviews/<id>/escalate-to-ce/"""
    review   = get_object_or_404(ChapterReview, pk=pk)
    reasoning = request.data.get('reasoning', '')

    # Find supervising CE via hierarchy
    ce = None
    try:
        se = request.user if request.user.role == 'se' else review.assigned_se
        if se:
            ce = se.editorial_assignment.supervisor
            if ce and ce.role != 'ce':
                ce = None
    except EditorAssignment.DoesNotExist:
        pass

    review.assigned_ce = ce
    _transition(review, ChapterReview.STATUS_SE_ESCALATED, 'assigned_ce', ce)

    if reasoning:
        EditorialNote.objects.create(
            review=review,
            author=request.user,
            note_type=EditorialNote.NOTE_TYPE_DECISION,
            content=f'[SE Escalation Reasoning] {reasoning}',
        )

    return Response({
        'status': 'escalated_to_ce',
        'review_id': review.id,
        'ce_assigned': ce.username if ce else None,
    })


@api_view(['POST'])
@permission_classes([IsSEOrAbove])
def se_remove(request, pk):
    """POST /api/editorial/reviews/<id>/remove/  — SE can remove clear violations."""
    review  = get_object_or_404(ChapterReview, pk=pk)
    reason  = request.data.get('reason', '')
    _transition(review, ChapterReview.STATUS_REMOVED)
    review.chapter.is_published = False
    review.chapter.save(update_fields=['is_published'])
    if reason:
        EditorialNote.objects.create(
            review=review,
            author=request.user,
            note_type=EditorialNote.NOTE_TYPE_DECISION,
            content=f'[Removal Reason] {reason}',
        )
    return Response({'status': 'removed', 'review_id': review.id})


class SETeamView(APIView):
    """
    GET /api/editorial/ae-team/
    Returns all AEs that report to the requesting SE.
    """
    permission_classes = [IsSEOrAbove]

    def get(self, request):
        user = request.user
        if user.role == 'se':
            ae_users = User.objects.filter(
                role='ae',
                editorial_assignment__supervisor=user,
            )
        else:
            # CE gets all AEs
            ae_users = User.objects.filter(role='ae')

        data = []
        for ae in ae_users:
            queue_count    = ChapterReview.objects.filter(
                assigned_ae=ae,
                status__in=['pending', 'ae_reviewing'],
            ).count()
            reviewed_today = ChapterReview.objects.filter(
                assigned_ae=ae,
                updated_at__date=timezone.now().date(),
                status__in=['ae_approved', 'ae_revision', 'ae_escalated'],
            ).count()
            data.append({
                'id':             ae.id,
                'username':       ae.username,
                'email':          ae.email,
                'queue_count':    queue_count,
                'reviewed_today': reviewed_today,
                'author_count':   ae.assigned_authors.count(),
            })
        return Response(data)


# ─── CE Views ─────────────────────────────────────────────────────────────────

class CEEscalationsView(generics.ListAPIView):
    """GET /api/editorial/ce-escalations/"""
    serializer_class   = ChapterReviewDetailSerializer
    permission_classes = [IsCE]

    def get_queryset(self):
        return ChapterReview.objects.filter(
            status=ChapterReview.STATUS_SE_ESCALATED,
        ).select_related(
            'chapter', 'chapter__story', 'author',
            'assigned_ae', 'assigned_se', 'assigned_ce',
        ).prefetch_related('notes', 'flags')


@api_view(['POST'])
@permission_classes([IsCE])
def ce_approve(request, pk):
    """POST /api/editorial/reviews/<id>/ce-approve/"""
    review = get_object_or_404(ChapterReview, pk=pk)
    _transition(review, ChapterReview.STATUS_CE_APPROVED)
    review.chapter.is_published = True
    review.chapter.save(update_fields=['is_published'])
    return Response({'status': 'ce_approved', 'review_id': review.id})


@api_view(['POST'])
@permission_classes([IsCE])
def ce_revision(request, pk):
    """POST /api/editorial/reviews/<id>/ce-revision/"""
    review  = get_object_or_404(ChapterReview, pk=pk)
    message = request.data.get('message', '')
    _transition(review, ChapterReview.STATUS_CE_REVISION)
    if message:
        EditorialNote.objects.create(
            review=review,
            author=request.user,
            note_type=EditorialNote.NOTE_TYPE_DECISION,
            content=f'[CE Revision Order] {message}',
        )
    return Response({'status': 'ce_revision_requested', 'review_id': review.id})


@api_view(['POST'])
@permission_classes([IsCE])
def ce_remove(request, pk):
    """POST /api/editorial/reviews/<id>/ce-remove/"""
    review = get_object_or_404(ChapterReview, pk=pk)
    reason = request.data.get('reason', '')
    _transition(review, ChapterReview.STATUS_REMOVED)
    review.chapter.is_published = False
    review.chapter.save(update_fields=['is_published'])
    if reason:
        EditorialNote.objects.create(
            review=review,
            author=request.user,
            note_type=EditorialNote.NOTE_TYPE_DECISION,
            content=f'[CE Removal — Final Order] {reason}',
        )
    return Response({'status': 'ce_removed', 'review_id': review.id})


@api_view(['POST'])
@permission_classes([IsCE])
def ce_suspend_author(request, pk):
    """POST /api/editorial/reviews/<id>/suspend-author/"""
    review = get_object_or_404(ChapterReview, pk=pk)
    reason = request.data.get('reason', '')
    author = review.author
    author.is_active = False
    author.save(update_fields=['is_active'])
    _transition(review, ChapterReview.STATUS_AUTHOR_SUSPENDED)
    if reason:
        EditorialNote.objects.create(
            review=review,
            author=request.user,
            note_type=EditorialNote.NOTE_TYPE_DECISION,
            content=f'[CE Author Suspension] {reason}',
        )
    return Response({'status': 'author_suspended', 'author_id': author.id})


# ─── Notes & Flags ────────────────────────────────────────────────────────────

class EditorialNoteCreateView(generics.CreateAPIView):
    """POST /api/editorial/notes/"""
    serializer_class   = EditorialNoteSerializer
    permission_classes = [IsAEOrAbove]


@api_view(['PATCH'])
@permission_classes([IsAEOrAbove])
def resolve_note(request, pk):
    """PATCH /api/editorial/notes/<id>/resolve/"""
    note = get_object_or_404(EditorialNote, pk=pk)
    note.is_resolved = True
    note.save(update_fields=['is_resolved'])
    return Response({'status': 'resolved'})


class ContentFlagCreateView(generics.CreateAPIView):
    """POST /api/editorial/flags/"""
    serializer_class   = ContentFlagSerializer
    permission_classes = [IsAEOrAbove]


class ContentFlagListView(generics.ListAPIView):
    """GET /api/editorial/flags/  — SE/CE sees all unresolved flags under them."""
    serializer_class   = ContentFlagSerializer
    permission_classes = [IsSEOrAbove]

    def get_queryset(self):
        qs = ContentFlag.objects.filter(resolved=False).select_related(
            'review', 'flagged_by', 'review__chapter', 'review__chapter__story',
        )
        if self.request.user.role == 'se':
            qs = qs.filter(review__assigned_se=self.request.user)
        return qs


@api_view(['POST'])
@permission_classes([IsSEOrAbove])
def resolve_flag(request, pk):
    """POST /api/editorial/flags/<id>/resolve/"""
    flag = get_object_or_404(ContentFlag, pk=pk)
    flag.resolved     = True
    flag.resolved_by  = request.user
    flag.resolution_note = request.data.get('note', '')
    flag.save(update_fields=['resolved', 'resolved_by', 'resolution_note'])
    return Response({'status': 'resolved'})


# ─── CE: Policy decisions ─────────────────────────────────────────────────────

class PolicyDecisionListCreateView(generics.ListCreateAPIView):
    """GET/POST /api/editorial/policy-decisions/"""
    serializer_class   = PolicyDecisionSerializer
    permission_classes = [IsCE]
    queryset           = PolicyDecision.objects.all().select_related(
        'review', 'decided_by', 'review__chapter',
    )


class EditorialPolicyListCreateView(generics.ListCreateAPIView):
    """GET/POST /api/editorial/policies/"""
    serializer_class = EditorialPolicySerializer
    permission_classes = [IsSEOrAbove]  # SE can propose; CE can approve

    def get_queryset(self):
        return EditorialPolicy.objects.all().select_related(
            'proposed_by', 'approved_by',
        )

    def perform_create(self, serializer):
        serializer.save(
            proposed_by=self.request.user,
            status=EditorialPolicy.STATUS_REVIEW
            if self.request.user.role == 'se'
            else EditorialPolicy.STATUS_DRAFT,
        )


@api_view(['POST'])
@permission_classes([IsCE])
def approve_policy(request, pk):
    """POST /api/editorial/policies/<id>/approve/"""
    policy = get_object_or_404(EditorialPolicy, pk=pk)
    policy.status      = EditorialPolicy.STATUS_ACTIVE
    policy.approved_by = request.user
    policy.published_at = timezone.now()
    policy.save(update_fields=['status', 'approved_by', 'published_at'])
    return Response({'status': 'policy_approved', 'policy_id': policy.id})


@api_view(['POST'])
@permission_classes([IsCE])
def reject_policy(request, pk):
    """POST /api/editorial/policies/<id>/reject/"""
    policy = get_object_or_404(EditorialPolicy, pk=pk)
    note   = request.data.get('note', '')
    policy.status = EditorialPolicy.STATUS_ARCHIVED
    policy.notes  = note
    policy.save(update_fields=['status', 'notes'])
    return Response({'status': 'policy_rejected'})


# ─── Org / assignment management (CE) ────────────────────────────────────────

class EditorAssignmentListCreateView(generics.ListCreateAPIView):
    """GET/POST /api/editorial/assignments/"""
    serializer_class   = EditorAssignmentSerializer
    permission_classes = [IsCE]
    queryset           = EditorAssignment.objects.all().select_related(
        'editor', 'supervisor',
    )


class AuthorEditorLinkListCreateView(generics.ListCreateAPIView):
    """GET/POST /api/editorial/author-links/"""
    serializer_class   = AuthorEditorLinkSerializer
    permission_classes = [IsCE]
    queryset           = AuthorEditorLink.objects.all().select_related(
        'author', 'assigned_ae',
    )


class EditorialTeamView(APIView):
    """
    GET /api/editorial/team/
    CE gets full org tree: each SE with their AEs and author counts.
    """
    permission_classes = [IsCE]

    def get(self, request):
        data = {'ce': [], 'se': [], 'ae': []}

        for ce in User.objects.filter(role='ce'):
            data['ce'].append({'id': ce.id, 'username': ce.username, 'email': ce.email})

        for se in User.objects.filter(role='se'):
            try:
                ce_sup = se.editorial_assignment.supervisor
                ce_name = ce_sup.username if ce_sup else None
            except Exception:
                ce_name = None

            escalation_count = ChapterReview.objects.filter(
                assigned_se=se, status=ChapterReview.STATUS_AE_ESCALATED,
            ).count()

            data['se'].append({
                'id':               se.id,
                'username':         se.username,
                'email':            se.email,
                'reports_to_ce':    ce_name,
                'escalation_count': escalation_count,
                'ae_count':         se.subordinates.filter(role='ae').count(),
            })

        for ae in User.objects.filter(role='ae'):
            try:
                se_sup = ae.editorial_assignment.supervisor
                se_name = se_sup.username if se_sup else None
            except Exception:
                se_name = None

            queue_count = ChapterReview.objects.filter(
                assigned_ae=ae,
                status__in=['pending', 'ae_reviewing'],
            ).count()

            data['ae'].append({
                'id':            ae.id,
                'username':      ae.username,
                'email':         ae.email,
                'reports_to_se': se_name,
                'queue_count':   queue_count,
                'author_count':  ae.assigned_authors.count(),
            })

        return Response(data)


# ─── Stats dashboard (role-aware) ─────────────────────────────────────────────

class EditorialStatsView(APIView):
    """
    GET /api/editorial/stats/
    Returns stats appropriate for the requesting editor's role.
    """
    permission_classes = [IsAEOrAbove]

    def get(self, request):
        user = request.user

        if user.role == 'ae':
            return Response({
                'queue_count': ChapterReview.objects.filter(
                    assigned_ae=user,
                    status__in=['pending', 'ae_reviewing'],
                ).count(),
                'urgent_count': ChapterReview.objects.filter(
                    assigned_ae=user,
                    status__in=['pending', 'ae_reviewing'],
                    priority='urgent',
                ).count(),
                'reviewed_today': ChapterReview.objects.filter(
                    assigned_ae=user,
                    updated_at__date=timezone.now().date(),
                ).exclude(status__in=['pending', 'ae_reviewing']).count(),
                'flagged_count': ContentFlag.objects.filter(
                    flagged_by=user, resolved=False,
                ).count(),
                'author_count': user.assigned_authors.count(),
            })

        elif user.role == 'se':
            ae_ids = list(
                user.subordinates.filter(role='ae').values_list('id', flat=True)
            )
            return Response({
                'escalation_count': ChapterReview.objects.filter(
                    assigned_se=user,
                    status=ChapterReview.STATUS_AE_ESCALATED,
                ).count(),
                'ae_active_count': User.objects.filter(
                    id__in=ae_ids,
                ).count(),
                'cleared_this_week': ChapterReview.objects.filter(
                    assigned_se=user,
                    resolved_at__gte=timezone.now() - __import__(
                        'datetime', fromlist=['timedelta']
                    ).timedelta(days=7),
                ).count(),
                'policy_actions_month': ChapterReview.objects.filter(
                    assigned_se=user,
                    updated_at__month=timezone.now().month,
                ).exclude(status__in=['pending', 'ae_reviewing', 'ae_escalated']).count(),
            })

        elif user.role == 'ce':
            from django.db.models import Count as DCount
            return Response({
                'ce_escalation_count': ChapterReview.objects.filter(
                    status=ChapterReview.STATUS_SE_ESCALATED,
                ).count(),
                'total_editors': User.objects.filter(
                    role__in=['ae', 'se'],
                ).count(),
                'chapters_cleared_month': ChapterReview.objects.filter(
                    resolved_at__month=timezone.now().month,
                ).count(),
                'content_removed_month': ChapterReview.objects.filter(
                    status=ChapterReview.STATUS_REMOVED,
                    resolved_at__month=timezone.now().month,
                ).count(),
                'pending_policies': EditorialPolicy.objects.filter(
                    status=EditorialPolicy.STATUS_REVIEW,
                ).count(),
                'se_count': User.objects.filter(role='se').count(),
                'ae_count': User.objects.filter(role='ae').count(),
            })

        return Response({})

# ─── Editor code: author-facing endpoints ─────────────────────────────────────

@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def validate_editor_code(request):
    """
    POST /api/editorial/validate-code/
    Body: { "code": "AX3K9PLM" }

    Public endpoint — lets the signup form validate an editor code in real-time
    before form submission, without revealing the AE's personal details.
    Returns: { valid: true, ae_display_name: "Amara O." }
         or: { valid: false, error: "..." }
    """
    from django.contrib.auth import get_user_model as _get_user_model
    _User = _get_user_model()

    code = request.data.get('code', '').strip().upper()
    if not code:
        return Response({'valid': False, 'error': 'Code is required.'}, status=400)

    try:
        ae = _User.objects.get(editor_code=code, role='ae')
        # Only expose display name, not email/username
        display = ae.get_full_name() or ae.username
        return Response({
            'valid':           True,
            'ae_display_name': display,
            'author_count':    ae.assigned_authors.count(),
        })
    except _User.DoesNotExist:
        return Response({'valid': False, 'error': 'Invalid editor code.'}, status=404)


@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def link_editor_by_code(request):
    """
    POST /api/editorial/link-editor/
    Body: { "code": "AX3K9PLM" }

    Authenticated authors can use this to:
      - Link themselves at signup if they skipped the code field
      - Change their editor later (e.g. if they switch to a new AE)

    Returns the updated link details.
    """
    user = request.user
    code = request.data.get('code', '').strip().upper()

    link, error = AuthorEditorLink.link_by_code(user, code)
    if error:
        return Response({'error': error}, status=400)

    from apps.editorial.serializers import AuthorEditorLinkSerializer
    return Response({
        'success': True,
        'message': f'You are now linked to editor {link.assigned_ae.username}.',
        'link':    AuthorEditorLinkSerializer(link).data,
    })


@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def my_editor_link(request):
    """
    GET /api/editorial/my-editor/
    Returns the requesting author's current editor link, or null if unlinked.
    """
    user = request.user
    try:
        link = AuthorEditorLink.objects.select_related('assigned_ae').get(author=user)
        ae   = link.assigned_ae
        return Response({
            'linked':       True,
            'link_method':  link.link_method,
            'assigned_at':  link.assigned_at,
            'ae': {
                'display_name': ae.get_full_name() or ae.username if ae else None,
                'author_count': ae.assigned_authors.count() if ae else 0,
            } if ae else None,
        })
    except AuthorEditorLink.DoesNotExist:
        return Response({'linked': False, 'ae': None})


@api_view(['GET'])
@permission_classes([IsAE])
def my_editor_code(request):
    """
    GET /api/editorial/my-code/
    Returns the requesting AE's invite code (generating it if needed).
    AEs share this code with authors so they get auto-linked.
    """
    user = request.user
    code = user.editor_code or user.generate_editor_code()
    return Response({
        'editor_code':  code,
        'author_count': user.assigned_authors.count(),
        'share_hint':   (
            f'Share this code with your authors so they can link to you at signup: {code}'
        ),
    })
