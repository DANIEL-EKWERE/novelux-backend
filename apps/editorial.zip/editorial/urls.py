from django.urls import path
from . import views

app_name = 'editorial'

urlpatterns = [

    # ── AE ────────────────────────────────────────────────────────────────────
    path('queue/',
         views.AEQueueView.as_view(),
         name='ae-queue'),

    path('reviews/<int:pk>/',
         views.AEReviewDetailView.as_view(),
         name='review-detail'),

    path('reviews/<int:pk>/approve/',
         views.ae_approve,
         name='ae-approve'),

    path('reviews/<int:pk>/request-revision/',
         views.ae_request_revision,
         name='ae-request-revision'),

    path('reviews/<int:pk>/escalate-to-se/',
         views.ae_escalate_to_se,
         name='ae-escalate-to-se'),

    # ── SE ────────────────────────────────────────────────────────────────────
    path('escalations/',
         views.SEEscalationsView.as_view(),
         name='se-escalations'),

    path('reviews/<int:pk>/se-approve/',
         views.se_approve,
         name='se-approve'),

    path('reviews/<int:pk>/se-revision/',
         views.se_request_revision,
         name='se-revision'),

    path('reviews/<int:pk>/escalate-to-ce/',
         views.se_escalate_to_ce,
         name='se-escalate-to-ce'),

    path('reviews/<int:pk>/remove/',
         views.se_remove,
         name='se-remove'),

    path('ae-team/',
         views.SETeamView.as_view(),
         name='se-ae-team'),

    # ── CE ────────────────────────────────────────────────────────────────────
    path('ce-escalations/',
         views.CEEscalationsView.as_view(),
         name='ce-escalations'),

    path('reviews/<int:pk>/ce-approve/',
         views.ce_approve,
         name='ce-approve'),

    path('reviews/<int:pk>/ce-revision/',
         views.ce_revision,
         name='ce-revision'),

    path('reviews/<int:pk>/ce-remove/',
         views.ce_remove,
         name='ce-remove'),

    path('reviews/<int:pk>/suspend-author/',
         views.ce_suspend_author,
         name='ce-suspend-author'),

    path('policy-decisions/',
         views.PolicyDecisionListCreateView.as_view(),
         name='policy-decisions'),

    path('policies/',
         views.EditorialPolicyListCreateView.as_view(),
         name='policies'),

    path('policies/<int:pk>/approve/',
         views.approve_policy,
         name='approve-policy'),

    path('policies/<int:pk>/reject/',
         views.reject_policy,
         name='reject-policy'),

    path('assignments/',
         views.EditorAssignmentListCreateView.as_view(),
         name='assignments'),

    path('author-links/',
         views.AuthorEditorLinkListCreateView.as_view(),
         name='author-links'),

    path('team/',
         views.EditorialTeamView.as_view(),
         name='team'),

    # ── Editor code (author-facing) ──────────────────────────────────────────
    path('validate-code/',
         views.validate_editor_code,
         name='validate-code'),

    path('link-editor/',
         views.link_editor_by_code,
         name='link-editor'),

    path('my-editor/',
         views.my_editor_link,
         name='my-editor'),

    path('my-code/',
         views.my_editor_code,
         name='my-code'),

    # ── Shared ────────────────────────────────────────────────────────────────
    path('notes/',
         views.EditorialNoteCreateView.as_view(),
         name='note-create'),

    path('notes/<int:pk>/resolve/',
         views.resolve_note,
         name='note-resolve'),

    path('flags/',
         views.ContentFlagListView.as_view(),
         name='flag-list'),

    path('flags/create/',
         views.ContentFlagCreateView.as_view(),
         name='flag-create'),

    path('flags/<int:pk>/resolve/',
         views.resolve_flag,
         name='flag-resolve'),

    path('stats/',
         views.EditorialStatsView.as_view(),
         name='stats'),
]
